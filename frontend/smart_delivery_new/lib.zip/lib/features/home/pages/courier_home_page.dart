import 'dart:async';
import 'package:flutter/material.dart';
import '../../../core/services/auth_service.dart';
import '../../../core/services/delivery_service.dart';
import '../../../models/delivery.dart';
import '../../../models/delivery_request.dart';
import '../../auth/pages/login_page.dart';
import 'courier_map_page.dart';

class CourierHomePage extends StatefulWidget {
  static const route = '/home/courier';
  const CourierHomePage({super.key});

  @override
  State<CourierHomePage> createState() => _CourierHomePageState();
}

class _CourierHomePageState extends State<CourierHomePage> {
  final _auth = AuthService();
  final _delivery = DeliveryService();

  bool _loading = true;
  Delivery? _currentDelivery;
  List<DeliveryRequest> _available = [];
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 5), (_) => _load(silent: true));
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _toast(String msg) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

  Future<void> _load({bool silent = false}) async {
    if (!silent) setState(() => _loading = true);
    try {
      final deliveries = await _delivery.myDeliveries();
      // current = latest not delivered
      final active = deliveries.where((d) => d.status != 'DELIVERED').toList();
      active.sort((a, b) => b.id.compareTo(a.id));

      final avail = await _delivery.availableRequests();

      if (!mounted) return;
      setState(() {
        _currentDelivery = active.isNotEmpty ? active.first : null;
        _available = avail;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  Future<void> _accept(DeliveryRequest r) async {
    try {
      final d = await _delivery.acceptRequest(r.id);
      if (!mounted) return;
      _toast('Accepted request #${r.id}');
      setState(() => _currentDelivery = d);
      // open map tracking page
      Navigator.push(context, MaterialPageRoute(builder: (_) => CourierMapPage(delivery: d)));
    } catch (e) {
      _toast(e.toString().replaceAll('Exception: ', ''));
    }
  }

  Future<void> _logout() async {
    await _auth.logout();
    if (!mounted) return;
    Navigator.pushNamedAndRemoveUntil(context, LoginPage.route, (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    final cur = _currentDelivery;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Livreur'),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
          IconButton(onPressed: _logout, icon: const Icon(Icons.logout)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(14),
              children: [
                Text('Current Delivery', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
                const SizedBox(height: 10),

                if (cur == null)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(14),
                      child: Text('No active delivery. You can accept a new request.'),
                    ),
                  )
                else
                  Card(
                    child: ListTile(
                      leading: const Icon(Icons.delivery_dining),
                      title: Text('Delivery #${cur.id} • ${cur.status}'),
                      subtitle: Text(
                        '${cur.deliveryRequest.pickupAddress}\n→ ${cur.deliveryRequest.deliveryAddress}',
                      ),
                      isThreeLine: true,
                      trailing: const Icon(Icons.map),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => CourierMapPage(delivery: cur)),
                      ),
                    ),
                  ),

                const SizedBox(height: 18),
                Text('Available Requests', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
                const SizedBox(height: 10),

                if (_available.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(14),
                      child: Text('No pending requests right now.'),
                    ),
                  )
                else
                  ..._available.map((r) => Card(
                        child: ListTile(
                          leading: const Icon(Icons.local_shipping_outlined),
                          title: Text('Request #${r.id} • ${r.status}'),
                          subtitle: Text('${r.pickupAddress}\n→ ${r.deliveryAddress}'),
                          isThreeLine: true,
                          trailing: FilledButton(
                            onPressed: cur != null ? null : () => _accept(r),
                            child: const Text('Accept'),
                          ),
                        ),
                      )),
              ],
            ),
    );
  }
}
