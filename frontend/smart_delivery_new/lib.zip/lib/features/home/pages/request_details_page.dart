import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../../../core/services/delivery_service.dart';
import '../../../models/delivery_request.dart';
import '../../../models/tracking_latest.dart';

class RequestDetailsPage extends StatefulWidget {
  final DeliveryRequest request;
  const RequestDetailsPage({super.key, required this.request});

  @override
  State<RequestDetailsPage> createState() => _RequestDetailsPageState();
}

class _RequestDetailsPageState extends State<RequestDetailsPage> {
  final _delivery = DeliveryService();

  TrackingLatest? _latest;
  String? _info;
  Timer? _timer;

  // We'll center map around pickup if we can parse coords from address
  LatLng _center = const LatLng(33.58990, -7.60390);

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 2), (_) => _poll());
    _poll();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  // parse "(lat, lng)" from "Pickup (33.1, -7.2)"
  LatLng? _parse(String s) {
    final m = RegExp(r'\(([-\d.]+)\s*,\s*([-\d.]+)\)').firstMatch(s);
    if (m == null) return null;
    final lat = double.tryParse(m.group(1) ?? '');
    final lng = double.tryParse(m.group(2) ?? '');
    if (lat == null || lng == null) return null;
    return LatLng(lat, lng);
  }

  Future<void> _poll() async {
    // only poll if active
    if (!widget.request.isActive) return;

    try {
      final latest = await _delivery.trackingLatest(widget.request.id);
      if (!mounted) return;
      setState(() {
        _latest = latest;
        _info = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _latest = null;
        _info = 'Waiting for driver assignment / tracking...';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final pickup = _parse(widget.request.pickupAddress);
    final dropoff = _parse(widget.request.deliveryAddress);
    if (pickup != null) _center = pickup;

    final markers = <Marker>[
      if (pickup != null)
        Marker(
          width: 44,
          height: 44,
          point: pickup,
          child: const Icon(Icons.my_location, size: 38),
        ),
      if (dropoff != null)
        Marker(
          width: 44,
          height: 44,
          point: dropoff,
          child: const Icon(Icons.location_on, size: 38),
        ),
      if (_latest != null)
        Marker(
          width: 54,
          height: 54,
          point: LatLng(_latest!.lat, _latest!.lng),
          child: const Icon(Icons.delivery_dining, size: 44),
        ),
    ];

    return Scaffold(
      appBar: AppBar(title: Text('Order #${widget.request.id}')),
      body: Column(
        children: [
          Expanded(
            child: FlutterMap(
              options: MapOptions(initialCenter: _center, initialZoom: 13),
              children: [
                TileLayer(
                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'smart_delivery_new',
                ),
                MarkerLayer(markers: markers),
              ],
            ),
          ),
          Card(
            margin: const EdgeInsets.all(12),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Status: ${widget.request.status}', style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  Text('From: ${widget.request.pickupAddress}'),
                  Text('To: ${widget.request.deliveryAddress}'),
                  const SizedBox(height: 8),
                  if (_info != null) Text(_info!),
                  if (_latest != null)
                    Text('Driver updated: ${_latest!.updatedAt} (every 2s)'),
                  const SizedBox(height: 8),
                  const Text('Payment: Cash', style: TextStyle(fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
