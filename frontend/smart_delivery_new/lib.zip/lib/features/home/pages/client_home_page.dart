import 'dart:async';
import 'package:flutter/material.dart';
import '../../../core/services/auth_service.dart';
import '../../../core/services/delivery_service.dart';
import '../../../models/delivery_request.dart';
import '../../auth/pages/login_page.dart';
import 'create_request_page.dart';
import 'request_details_page.dart';

class ClientHomePage extends StatefulWidget {
  static const route = '/home/client';
  const ClientHomePage({super.key});

  @override
  State<ClientHomePage> createState() => _ClientHomePageState();
}

class _ClientHomePageState extends State<ClientHomePage> {
  final _auth = AuthService();
  final _delivery = DeliveryService();

  bool _loading = true;
  List<DeliveryRequest> _all = [];
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    _load();
    _refreshTimer = Timer.periodic(const Duration(seconds: 5), (_) => _load(silent: true));
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    if (!silent) setState(() => _loading = true);
    try {
      final list = await _delivery.myRequests();
      list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      if (!mounted) return;
      setState(() {
        _all = list;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  DeliveryRequest? get _current {
    for (final r in _all) {
      if (r.isActive) return r;
    }
    return null;
  }

  List<DeliveryRequest> get _history => _all.where((r) => r.isFinished).toList();

  void _toast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _logout() async {
    await _auth.logout();
    if (!mounted) return;
    Navigator.pushNamedAndRemoveUntil(context, LoginPage.route, (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    final current = _current;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Smart Delivery'),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
          IconButton(onPressed: _logout, icon: const Icon(Icons.logout)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: current != null
            ? () => _toast('You already have an active delivery.')
            : () async {
                final created = await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const CreateRequestPage()),
                );
                if (created == true) _load();
              },
        label: const Text('New Order'),
        icon: const Icon(Icons.add),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.all(14),
                children: [
                  Text('Current Delivery', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 10),

                  if (current == null)
                    const _EmptyCard(text: 'No active delivery. You can create a new order.')
                  else
                    _RequestCard(
                      r: current,
                      onTap: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => RequestDetailsPage(request: current)),
                        );
                        _load(silent: true);
                      },
                    ),

                  const SizedBox(height: 18),
                  Text('History', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 10),

                  if (_history.isEmpty)
                    const _EmptyCard(text: 'No history yet.')
                  else
                    ..._history.map((r) => _RequestCard(
                          r: r,
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => RequestDetailsPage(request: r)),
                          ),
                        )),
                  const SizedBox(height: 80),
                ],
              ),
            ),
    );
  }
}

class _EmptyCard extends StatelessWidget {
  final String text;
  const _EmptyCard({required this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            const Icon(Icons.info_outline),
            const SizedBox(width: 10),
            Expanded(child: Text(text)),
          ],
        ),
      ),
    );
  }
}

class _RequestCard extends StatelessWidget {
  final DeliveryRequest r;
  final VoidCallback onTap;
  const _RequestCard({required this.r, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final price = r.priceMru;
    return Card(
      child: ListTile(
        onTap: onTap,
        leading: const Icon(Icons.local_shipping_outlined),
        title: Text('#${r.id} • ${r.status}'),
        

        subtitle: Text(
          '${r.pickupAddress}\n→ ${r.deliveryAddress}'
          '${price != null ? "\nPrice: ${price.toStringAsFixed(2)} MRU (cash)" : ""}',
        ),

        isThreeLine: true,
        trailing: const Icon(Icons.chevron_right),
      ),
    );
  }
}
